using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eStore.Pages.User
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
