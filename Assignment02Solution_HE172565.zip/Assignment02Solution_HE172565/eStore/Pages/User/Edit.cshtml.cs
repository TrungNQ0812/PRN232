using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eStore.Pages.User
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
