using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;
using System.Text;
using BusinessObject;

namespace eStoreClient.Pages.Members
{
    public class EditModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiBaseUrl = "http://localhost:5000/api/MemberAPI";

        public EditModel(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("API");
        }

        [BindProperty]
        public Member MemberToEdit { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (HttpContext.Session.GetString("Role") != "admin")
                return RedirectToPage("/Login");

            var response = await _httpClient.GetAsync($"{_apiBaseUrl}/all");
            if (response.IsSuccessStatusCode)
            {
                var listJson = await response.Content.ReadAsStringAsync();
                var list = JsonSerializer.Deserialize<List<Member>>(listJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                MemberToEdit = list?.FirstOrDefault(m => m.MemberId == id);
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            var json = JsonSerializer.Serialize(MemberToEdit);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PutAsync($"{_apiBaseUrl}/update/{MemberToEdit.MemberId}", content);
            if (response.IsSuccessStatusCode)
                return RedirectToPage("/Members/Index");

            ModelState.AddModelError("", "Update failed.");
            return Page();
        }
    }
}
