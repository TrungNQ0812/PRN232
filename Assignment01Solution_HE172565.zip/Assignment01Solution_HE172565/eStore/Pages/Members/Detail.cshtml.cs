using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eStoreClient.Pages.Members
{
    public class DetailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
