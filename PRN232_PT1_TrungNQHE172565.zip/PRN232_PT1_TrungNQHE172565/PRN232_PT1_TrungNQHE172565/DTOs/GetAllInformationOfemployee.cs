﻿namespace PRN232_PT1_TrungNQHE172565.DTOs
{
    public class GetAllInformationOfemployee
    {
    }
}
