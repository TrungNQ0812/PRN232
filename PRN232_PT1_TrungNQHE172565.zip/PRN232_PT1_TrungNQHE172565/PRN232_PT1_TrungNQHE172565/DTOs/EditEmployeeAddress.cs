﻿namespace PRN232_PT1_TrungNQHE172565.DTOs
{
    public class EditEmployeeAddress
    {
        public string Address { get; set; }
    }
}
